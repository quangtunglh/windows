JATDevice.cmd by s1ave77
(Referral Link for s1ave77: http://forums.mydigitallife.info/forum.php?referrerid=293479)


CREDITS:
	CODYQX4 & mikmik38 & nosferati87 & qad & deagles & Hotbird64 & jm287 & sirWest & CyNecx for the ingenious KMS Server Services/Emulators
	ColdZero & ms-7 & MasterDisaster & BetonMAN & PAYMYRENT & abbodi1406 & xinso for coding know-how.
	
	woot332 for amazing Windows 9 PID Viewer
	ASV93 for amazing PKeyConfigReader
	janek2012 for amazing PID Checker
	ColdZero for amazing ePID Generator
	Bob65536 for amazing KeyInfo
	Hotbird64 for amazing License Manager
	wtarkan for amazing RegCovert (to batch files)
	Alphawaves for amazing OEMDump
	nechrist for good ideas and constant testing to find the bugs i produce.
	ratzlefatz for big help with Office 16
	
	All mentioned are members of MDL (forums.mydigitallife.info).
	
	synchronicity for amazing wimlib-imagex
	Hrvoje Nik�ic' and Giuseppe Scrivano for amazing wget
	Simplix for amazing Win 7 Simplix-Pack
	Michal Gajda for amazing Windows Update PowerShell Module
	Mark Russinovich for amazing SysInternals
	
	No clue whom to thank for RWEverything (only found a Jeff so far)?

SPECIAL THANKS:
	To Microsoft(tm) for their amazing command line tools (i.e. dism, imagex, powershell, oscdimg and others more)


USAGE: 

    General usage hints:
		Activation Solutions for Windows 7, 8, 8.1, Servers, Office 14, 15, 16, Project and Visio 
        If you want to run any given option with "Default:" values, no need for intervention, simply hit <ENTER>
        as long as script isn�t closed, last entered values for any variables will be selected in next attempt as new "Default:"
	
	
FEATURES:

    KMS Server Emulator
        run Emulator by CODYQX4, deagles, Hotbird64 and sirWest (&jm287)
		Emulator of sirWest (&jm287) is started via Service Menu
        only one Emulator can run at a time
        specify all needed options during initialisation
        Firewall rules are created automatically and can be removed, if wished
        stopping the Emulator deletes all traces
		
    KMS Server Service Install
        install Services by CODYQX4, deagles, Hotbird64 and sirWest (&jm287)
        Services can be installed side by side, if different names and ports are used
        specify all needed options during install
        Firewall rules are created automatically and can be removed, if wished
        options can be changed for the installed service
        uninstall deletes all traces

	Hooked KMS Servers (Server and Localhost Redirect Hook)
		run Emulators by qad and CyNecx, last offers option for Emulator or Service
	
	KMS Client Emulator
		KMS Client Emulators by CODYQX4 and Hotbird64 for checking functionality
		now have their own Menu	
  
    Check Status
        KMS Client Emulators by CODYQX4 and Hotbird64 for checking functionality
        Check Service existence (now gathers the port used by the Service)
		Check whether Port is used (when nothing found it offers Option to Check for installed Service)
		Check Emulator running
        Check activation status of the host machine
        Restart/Start/Stop Service manually (in case Service is e.g. installed in start mode "demand")
        IP Lookup
        option to clear all system logs
     
    Activation
        Services and Emulators can be used as wished, or any IP in LAN or Internet
        install key for Windows with automatted key detection of most members of Win 7/8 and the Servers family
        activate Windows Vista, 7, 8, and 8.1 and Office 2010/2013/2016 ProPlus, ProjectPro and VisioPro
        Office installations will be detected even if installed in custom paths
		option to convert Office 15/16 Retail to Volume
		option to uninstall interferring Office Licenses
		option to download/install Office 2016
		option to create re-activation tasks (Running a second time will delete the task)
        option for instant activation in one batch
		Quick & Dirty Mode for VL activation
		Option to reinstall license files
		
    TOOLS MENU:
		Server Core Install Options:
			copy all files to systemdrive and add the Config Script to autostart
			come comfort when running in CMD only environments (Server Core or Windows Embedded) 
        start system panel applets from within the script
		start some more useful stuff
        some comfort when running in CMD only environments (Server Core or Windows Embedded)
		featuring 'ePID Generator' v1.5d by ColdZero
		PID Decrypter
		PKeyConfigReader by ASV93
		PID Check by janek2012
		KeyInfo by Bob 65536
		LicenseManager by Hotbird64
		RegConvert by wtarkan to convert REG to BAT
		OSInfoNT by 38956 
		OEMDump by Alphawaves
		WATFix by Daz
		Office 2010/13 FixIts
	
	SYSTEMTOOLS MENU:
		REGTWEAKS: for several useful situations
			Cascading Context menus with elevation
				TOOLS (elevated CMD, Magnifier, Regedit...)
				MAINTENANCE (Sytem Management Snipplets)
				MAINTENANCE II (System Panel Snipplets)
				POWER Options (Loggoff, Lock, Reboot, Shutdown...)
			En/Disable Hybridboot
			Verbose Mode On/Off
			WIM Context menu
			Show/Hide hidden Sytemfolders/files and Extensions
			Double/Single Click Switch
			CMD/PS here
			Take Ownership
		UPDATE NSTALLER: New Powershell Script to update even a Win 8.1 in Audit Mode
		DISKPART: Prepare Win Boot Environment, Create/Detach VHDs, create bootable pendrive (gathering data, then run batch) with copy interface
		BATCH RENAME: with several File naming options
		DISM & IMAGEX: Cature/Check WIM, (Un)Mount, Add/Remove Packages, (Un)Load Registry Hives, Change System Locale and much more
		VSS ADMIN (Volume Shadow Storage Service)
		ONLINE DISM
			Update Component Cleanup
			Restore Component Store
			Change Server SKU
			Modern Apps listing/uninstall
			Updates listing/uninstall for online system or offline system (in dual-boot or Win RE/SE/PE)
		SIMPLIX MENU (online install and offline integration)
		REARM Win7	
			Rearm and Restore Windows 7 / Server 2008 R2 Rearm Count
			Set Date
		PERFORMANCE INDEX	
			Check Windows Performance Index
			Run Windows Performance Index with various options
		.NET
			Check/Verify installed versions
			Enable .NET 3.5 in Win 8/8.x
		SPEECH GENERATOR
			.NET Repair
		FILE WRITE/COMPARE	
			FileName2TextFile
			Compare 2 Text Files
			Check/Compare File Hashes
		MOUNT ISO/VHD with Powershell
		UMPACK MSI FILES
		DOWNLOAD MENU
			cURL Check
			Download Files (from TXT file) with Wget (spider function)
			Download Files (from TXT file) with Powershell
		KEYDUMP MENU
			Dump OA 3.0 Key with Powershell or RWEverything (if mismatch with installed key Install is directly offered)
		REG CHANGE MENU
			Change even restricted registry keys (PS)
		WMI CHECK MENU
			Check Partition Layout
		Checkdisk
		Drive Cleanup
		System file integrity check
		Edit Hosts File
		Dis/Enable Hibernation
		Turn Windows Firewall On/Off
		Delete KMS Info
		Enable DNS Caching
	
	SYSINTERNALS, TASKKILL, BOOT MENU:
		Autoruns
		Processexplorer
		Autologon 
		NtFSInfo
		TCPView
		Hex2Dec
		PsInfo
		Pendmoves
		Move File
		Load Order
		PsPasswordChange
		Directory Usage
		Regjump
		Secure Delete
		Hash Check
		Menu with manual and automatic taskkill for hanging processes
		Disable/Enable Win 8 Bootmenu
		Boot directly to Win RE
		Add Safeboot Entry to Boot Menu to directly boot into Safe Mode
		Add new entry for Windows install
		Backup and Restore Boot menu
		
		
CHANGELOG:

	vXXVI
	--defaulted sai and sri values to their max
	--added correct generic Win 10 Home Retail key (thanks to Heidegger)
	--added correct generic Win 10 Home SL Retail key (thanks to Tito)
	--download of Vnext Office got smarter (start, generate link, copy/paste to opening TXT, >>>START)

	vXXV
	--added offer to install matching generic Retail key when Win 10 (Core/Pro/Ent no N) is detected
	--corrected lisense uninstall message output (%errorlevel% is always 0, for uninstall and error)
	--added automatted (Grace/Trial) License Unistall for Office 15+16
	--fixed little error in Vnext download, due to 1024 char limit in set /p

	vXXIV
	--automatted the license uninstalls for Office 16
	--added option to download the Vnext Office ProPlus Offline Setup (Project/Visio included)
	--added option to install Vnext Setup (offers choices for Office, Project and Visio)
	--busy ratzlefatz discovered a way to get Online Setups from MS directly so:
	--added option to download Office Professional (Project/Visio) Online Setup (Project/Visio must be gathered separately)

	vXXIII
	--added additional checks to Windows activation to avoid KMS Activation of licensed Non-Volume Versions
	--added support for Office 365 Professional (MS Online Install) thanks to ratzlefatz

	vXXII
	--Office checks re-worked to cover Project and/or Visio without Office
	--updated Win 10 ADK to 10.0.10240.16384
	--again more code optimization

	vXXI
	--more code optimization
	--reworked CHECK and ACTIVATION Sections
	--added Office 16 support
	--added Project and Visio support for Office 14/15/16
	--added option to uninstall interferring Office Licenses
	--re-added Task Creation for re-activation (Running a second time will delete the task)


	##########################################################

	vXX
	--VERSION JUMP TO HONOR THE OVERHAUL
	--cutted out old (miserably implemented) weirdnesses, tons of redundant code and bugs/slips
	--ADK files updated to 10.0.10075, Win 7 will still use Win 8.1 ADK by default
	--option to switch DISM version
	--updated janek2012s PID Checker to v1.2.0.601
	--Powershell Windows Update Module got hide/unhide option
	--see unreleased vXII.3 changelog for detailed changes done
	
	##########################################################
	
	vXII.3 [unreleased]
	--updated CREDITS section of Readme/Thread
	--reworked Text to Speech module in SYSTEM TOOLS
	--completely reworked REG TWEAKS MODULE (now uses reg add commands instead of importing REG files)
	--added CMD/Powershell here Context Menu (adapted script from Shenj) and Take Ownership to REG TWEAKS MODULE
	--all Context Tweaks now use their own Key to avoid trouble
	--updated ADK to latest version available for Win 8.1
	--added option to export single-index WIM/ESD from folder into new WIM/ESD with dism/wimlib-imagex to DISM/IMAGEX MODULE
	--reworked several parts in DISM/IMAGEX MODULE
	--added option to write file names w/o relative path, size, date and time to TXT file to FILE MENU
	--changed way of text file compare in FILE MENU
	--added option to check/compare file hashes (single/folder) to FILE MENU
	--changed the way to get installed Updates via WMIC to gather Updates by determining Security Updates, Hotfixes and normal Updates in WINDOWS UPDATE INSTALLER MODULE
	--added option to change even restricted registry keys (PS) to new REG CHANGE MENU in SYSTEM TOOLS
	--added option to check owner of a registry key (PS) to new REG CHANGE MENU in SYSTEM TOOLS
	--added option to check WMI for partition layout in new WMI CHECK MENU in SYSTEM TOOLS
	--changed wget text file download output
	--reworked OA 3.0 Key capture from BIOS/UEFI (Powershell/RWEverything) in new KEYDUMP MENU in SYSTEM TOOLS
	--if OA 3.0 Key doesn't match with installed key tool will offer to install the captured key directly
	--re-added RWEverything to the TOOLS MENU
	--updated wimlib-imagex to 1.7.3 Final (thanks to synchronicity)
	vXII.2
	--added option to directly append adresses to host file (powershell snipplet by Mr Jinje)
	--added Restart Explorer to TOOLS context menu in REG TWEAKS (integration by Mr Jinje)
	--new DOWNLOAD Menu in SYSTEMTOOLS with cURL check; wget and powershell download from textfile
	--updated esddecrypter to v2 to handle Win 10 ESDs directly (thanks to qad)
	--updated wimlib-imagex to v 1.7.3 BETA
	--corrected Restore Health from Install File in Online DISM Menu
	--added option to Scan and Restore Health of offline Windows to Online DISM Menu
	vXII.1
	--updated PID viewer by woot332 to 1.4.9d (09/25/2014)
	--updated Hotbird64s Emulator/Service/Client/Manager to v2.5 (03/10/2014)
	--key check now gathers Preview keys without error
	--added detection for Pro and Enterprise Preview builds, ProfessionalWMC will show Win 8.1 and is treated as this
	vXII
	--several bug and inconsistency fixes
	--updated PID viewer by woot332 to 1.4.8f (09/16/2014)
	--added option to mount ISO and VHD files with Powershell to SYSTEM TOOLS
	--added option to unpack MSI Installer Files to SYSTEM TOOLS
	--generalized the Create ProfessionalWMC option to upgrade to any Target Edition in DISM/IMAGEX MODULE
	vXI.9
	--thanks to abbodi1406 pushing me to support x86 DISM/IMAGEX, DONE.
	--added option to manage drivers to ONLINE DISM MENU and DISM/IMAGEX MODULE
	--added options to list/write/enable/disable Features to ONLINE DISM MENU and DISM/IMAGEX MODULE
	--moved option to write names of files in a folder to text file (w/o extension) to SYSTEMTOOLS
	--added option to compare two text files, e.g. Updates Folder Content List (file names without extension) against already integrated Updates to SYSTEMTOOLS (thanks to Scorpion931024 for idea)
	--Update Integration in DISM/IMAGEX MODULE now checks Updates Folder Content List against already integrated Updates and only offers/unpacks/integrates the missing ones
	--Update Installation in UPDATE INSTALLER MODULE now checks Updates Folder Content List against already installed Updates and only offers/unpacks/installs the missing ones
	--fixed a bug in Set Flags part of ProWMC creation in DISM/IMAGEX MODULE
	--added check for Win 8 or Win 8.x for all ProWMC Tokens Swaps in DISM/IMAGEX MODULE
	--ironed out several little 'flaws'
	vXI.8
	--updated Hotbird64s Emulator/Service to v2.3.1 (07/25/2014), now with verbose logging with loglevel 4
	--merged check/verify installs, install .NET 3.5 on Win 8/8.x and Repair installsnew into .NET sub menu in SYSTEM TOOLS 
	--merged Win7 Rearm/Restore Rearm Count/Set Date functions into sub menu in SYSTEM TOOLS
	--merged Performance Index functions into sub menu in SYSTEM TOOLS
	--merged Scan/Restore Component Store, Analyse/CleanUp/ResetBase, Change Server SKU into ONLINE DISM sub menu in SYSTEM TOOLS
	--added save/restore/remove Default App Associations into ONLINE DISM sub menu in SYSTEM TOOLS
	--added Modern Apps listing/removing to ONLINE DISM sub menu in SYSTEM TOOLS
	--added Updates listing/removing for online system or offline system (in dual-boot or Win RE/SE/PE) to ONLINE DISM sub menu in SYSTEM TOOLS
	--reworked and refined input and output behavior of most DISM AND IMAGEX functions
	--added 'Create ISO' to DISM AND IMAGEX, if no ei.cfg found, creation is offered, if ProfessionalWMC Index is found Tokens Swap is offered, both skippable
	--added sub menu for Modern Apps listing/removing to DISM AND IMAGEX
	--merged Mount/Unmount/Discard to sub menu and added Commit/Remount for listing/adding/removing to DISM AND IMAGEX
	--merged Add/Remove Updates functions to sub menu for listing/adding/removing to DISM AND IMAGEX
	--added option to re-mount/commit images to Un/Mount/Commit in DISM AND IMAGEX
	--merged SWM handling (ImageX, DISM and wimlib-imagex) to own sub menu in DISM AND IMAGEX
	vXI.7
	--added little UI for Simplix Pack Install and Integration to SYSTEM TOOLS
	--refreshed 'DISM & IMAGEX' Menu and added wimlib-imagex and decrypt.exe to introduce new features
	--New Features:
		# List Image Content
		# Convert ESD to WIM directly
		# Decrypt Windows Store ESDs
		# Convert Windows Store ESD to install.wim/esd or to ISO with WIM or ESD (for ProfessionalWMC tokens are switched automatically) + ei.cfg
		# Optimize WIMS or ESDs with or w/o --recompress option
		# Extract Files directly from WIM or ESD
		# Update Files directly in WIM or ESD
		# Delete Index
	--added option to add any Tool to Autostart [HKLM\Software\Microsoft\Windows\CurrentVersion\Run] to TOOLS Menu
	--added VSS Admin Control to SYSTEMTOOLS
	vXI.6
	--System File Integrity Check now checks offline Windows
	--'Create ProfessionalWMC' in DISM now offers to use/copy generic Tokens for Win 8.1, which are shipped with the tool
	--System Check Improvements, now Activation-ID is gathered correctly for current Licensing Channel
	--added option to activate RETAIL/OEM/MAK Systems online
	vXI.5
	--updated Hotbird64s Emulator/Service to v2.2
	--added SKU-ID check to SYSTEMTOOLS
	--added option to change Server SKU (e.g. ServerStandard to ServerDatacenter or Eval to RTM) to SYSTEMTOOLS
	--current Windows Product Key is now parsed and shown completely
	--several code fixes
	vXI.4
	--activation checks have been simplyfied
	--added 'Create GPT Layout' option to DISKPART Module
	vXI.3
	--fixed some bugs in Emulator Section
	vXI.2
	--updated deagles Emulator/Service to build 1.6
	--several little output fixes/improvements
	vXI.1
	--cosmetic fixes (special thanks to abbodi1406)
	--fixed path in Tool Install process
	--refined options dialogue in DISKPARTs Windows Environment Creation
	--added option to create/detach VHDs to DISKPART
	vXI
	--next big rework stage is done time for a version jump
	--departed TOOLS Section from main script to keep it maintainable
	--merged REARM & STUFF into TOOLS and SYSTEMTOOLS
	--merged SYSINTERNALS, TASKKILL & BOOT into one
	--TOOLS SECTION now with new layout for more functions
	--updated to kms-hgm 2.1 by Hotbird64
	--re-added LicenseManager by Hotbird64
	--re-arranged DISM & IMAGEX Menu
	--added option to prepare Windows Boot Environment to DISKPART Menu
	--added Apply option to DISM & IMAGEX Menu
	--Apply can add Boot Sector so with DISKPART Windows can be installed via Win8.1SE (Pimped with choice.exe) pen drive with WIMs
	--added split/merge WIM/SWM functions to DISM & IMAGEX Menu
	--RegConvert by wtarkan to convert REG to BAT
	--OEMDump by Alphawaves
	--OSInfoNT by 38956 
	--FileName2TextFile script added
	--some new Sys Pane Applets added
	--little glitches and layout errors cleaned up
	
	vX.7
	--mostly little layout changes and bugfixes
	vX.6
	--added new way to run as Admin (thanks to BetonMAN)
	--changed method to restore Win 7 rearm count (thenks to BetonMAN and Humphrey)
	--fixed bug in ID loop, that could gather Office ID instead of Windows one
	vX.5
	--added option to automatically add features (folder order/get order from text file) for all indices in DISM
	--more cross-options in DISM
	--code cleansing as always
	vX.4
	--fixed bug that prevented creating IP for the session
	--added TEST AND STUFF menu with Performance Index for Win 8.x systems
	--still fixing little bugs
	vX.3
	--some updates and additions in code for DISM
	--added option to check/enable/manually rum Trim for SSDs
	vX.2
	--fixed a bug in Windows Activation
	vX.1
	--changes in output for the Win Update PS Module
	--added option to search for an installed Update to Win Update PS Module
	--added option to get the install order for Windows Updates from text file for DISM and Update Batch Installer
	--added option to automatically check all indices in DISM
	--added option to automatically extract all indices with max. compression to new WIM in DISM
	--added option to automatically extract all indices with recovery compression to new ESD in DISM
	--added option to automatically mount/unmount all indices in DISM
	--added option to automatically enable .NET for all indices in DISM
	--added option to automatically ResetBase all indices in DISM
	--all automatted functions marked with [A/S]
	--added options to repeat several processes
	--updated .NET repair tool (thanks to abbodi1406)
	vX
	--last layout change to prevent bugging for now
	--added option to use mounted WIM for /RestoreHealth, in case no internet available

	v9.5
	--MAINMENU slightly reworked to avoid too much submenus, which drove me nearly mad
	--slight fixes and adaptions
	--added DISM files from latest Leak/Update (thanks to abbodi1406)
	--PKeyConfigReader by ASV93 updated to 1.4.3.3

	v9.2
	--fixing/fixing/fixing
	--System Check now grabs the BuildLabEx value instead of asking WMI
	--added options for /scanhealth and /resetbase to SystemTools
	v9.1
	--still fixing the bugs i produce, so bare with me...:)
	--was tested for most functions but needs some testing by nechrist
	v9.0
	--further small improvements and code cleaning
	v8.9
	--last found little glitches fixed
	--PKeyConfigReader by ASV93 updated to 1.4.1.0
	--switched to PID Viewer by woot332
	--added 'Show Name- and Edition-Flags' to DISM & IMAGEX part
	v8.8
	--further fixing little bugs
	--added kms-hgm 2.0 by Hotbird64
	--added PKeyConfigReader by ASV93
	--added KeyInfo by Bob65536
	v8.7
	--further bugfixes
	--small features added (ComponentStore Analysis and some others...)
	v8.6
	--minor bugfixes
	--added install of 'Windows Management Framework 3.0' to use PowerShell 3.0 features in Win 7 (if not found in the system, patch will be offered during Copy-Process)
	--added more Rearm options for Win 7
	v8.5
	--Updated KMS Servers to latest versions
	--UPDATE INSTALLER now uses Powershell Script, to update even Win 8.1 in Audit Mode
	--Some System Tweaks added
	--Further code cleaning and layout changes
	v8.1
	--Tons of code cleaning and layout changes
	--New Tools Subdirectory: SysInternals by Mark Russinovitch added (see Feature List)
	v8.0
	--Tool has been renamed
	--completely reworked script to manage the madness in a much more sophisticated way
	--dumped some ancient heritage
	--tool became drastically smaller in size and easier to maintain
	
	
	v7.2
	--added new checks for build infos
	v7.1
	--added Server and Hook by CyNecx
	--new INDICATOR function: On unctivated Systems Tool starts with RED background, after activation it turns BLACK
	v7.0
	--added Support for Win 8.1 family (credits to quad for server with dll hook and xinso for scripts)
	--updated Service, Emulator and Client by CODYQX4 to latest builds [12/30/2013]
	--optimized the activation part
	--added uninstall option to Activation for "Create Reactivation Task"
	--layout changes
	
	
	v6.3
	--updated key detection for Win 8.1 family
	--added option to en/disable Sleep Mode in SYSTEM TOOLS
	v6.2
	--updated DISM & IMAGEX
	v6.1
	--added BATCH RENAME with several naming options to TOOLS
	--added DISM & IMAGEX to TOOLS (see Features)
	--added system file integrity check to SYSTEMTOOLS
	--added option to enable .NET 3.5 in Windows 8 to SYSTEMTOOLS
	--added option to edit the Hosts file to SYSTEMTOOLS
	v6.0
	--Menu layout changed for most menus
	--added Option to start CMD from within the MAINMENU
	--added Option to Check whether a specific Port is in use
	--Check for Server Existance now determines the used port of any of the 4 Services 
	--added Option to automatically create Reactivation Task (see Activation Features)
	--added Option to automatically create Instant Activation Script (see Activation Features)
	
	
	v5.7
	--added Service and Emulator by sirWest (&jm287)
	--Emulator is started via Service-Menu, during the Service Creation there�s a choice for either service or Emulator
	--added 'ePID Generator v1.5d' by ColdZero (now offers option to generate ePIDs per SKU)
	v5.6
	--OS detection now uses reg-query, as 'wmic' started to show localized output in Win 8.1 Preview builds
	--slighly reworked key input for better visibility of detected GVLK (Win 7/8/8.1 and Servers 2008 R2/2012/2012 R2)
	v5.5
	--updated Service, Emulator and Client by CODYQX4 to latest builds [06/13/2013]
	--reworked TASKKILL and WIN BOOT MENU for better handling
	--simplified 'Instant Actvation' Module
	--some little bug fixes
	v5.4
	--fixed some bugs in TOOLS and SYSTEM TOOLS menu
	--changed input layout for 'Safeboot entry install' and 'Taskkill'
	v5.3
	--added REGTWEAKS for several useful situations, e.g disable hybrid boot, add Win Defender to context menu a.o.
	--added UPDATE INSTALLER for installing .msu and .msp Updates in a batch
	--added DISKPART for creating bootable pendrive (gathering data, then run batch) with copy interface
	--TOOLS now has a SYSTEMTOOLS submenu (see description above for info)
	--added GVLK for Win 8.1 Preview and Server 2012 R2 Preview releases for testing
	v5.2
	--updated to latest KMS Service/Emulator build by CODYQX4 [05/31/2013]
	--it�s now possible to set specific ePID for each product separately in CODYs Service (Option [A])
	v5.1
	--fixed bug in Office Activation Module
	v5.0
	--fixed bug in Instant Activation Module
	v4.9
	--fixed bug in Hotbird64s Service Setup
	--some code cleaning
	v4.8
	--bugfixing
	--added Checkdisk to TOOLS
	--added god mode to TOOLS
	v4.7
	--added Client Emulator by Hotbird64 to Check Section
	--added License Manager by Hotbird64 to TOOLS Section
	--added check for already installed script to Server Core Install Section
	v4.6
	--updated to latest KMS Service/Emulator build by Hotbird64 (1.3) [05/03/2013]
	v4.5
	--little optimizations for code and design
	v4.4
	--implemented option for changing start type of installed Service (Change Settings Section)
	--some code optimization
	v4.3
	--bugfixing
	v4.2
	--bugfixing
	--new option for instant task
	--implemented check for installed service in service task
	v4.1
	--Completely reworked Task Scheduler (see Features for more info)
	v4.0
	--bugfixing (thanks to nechrist for finding them :))
	v3.9
	--updated to latest KMS Service/Emulator build by Hotbird64 (1.2)
	--updated to latest KMS Service build by deagles (1.4)
	--some code additions
	v3.8
	--updated to latest KMS Service/Emulator build by Hotbird64 (1.1)
	--new input layout for Server Emulator by Hotbird64
	v3.7
	--implemented last build of deagles KMS Server Emulator (1.0) as additional option
	--changed layout for input of RandomKMSPID-Value of builds by Hotbird64
	v3.6
	--implemented last build of Hotbird64s KMS Server Emulator as additional option
	--implemented last build of Hotbird64s KMS Server Service (1.0.0.1) as an update
	v3.5
	--implemented last build of Hotbird64s KMS Server Service (0.91) with option to change settings :) as additional features
	v3.4
	--added option to change Service Settings for deagles Service, as they are handled differently
	v3.3
	--added VLActivationType value for faster response
	--implemented last build of deagles KMS Server Service (1.2) as additional feature
	v3.2
	--implemented last build of CODYs KMS Server Service (sai and sri values are now working correctly)
	v3.1
	--did some code cleaning and deleted obsolete parts
	v3.0 (CODYQX4 version only)
	--updated to new Service and Emulator (released 03/22/2013)
	v2.9
	--added option to install tool in systemdrive and add to Autostart
	v2.8
	--added option to schedule multiple different reactivation tasks for Windows and Office
	v2.7
	--added more options for reactivation tasks of Windows and Office
	--added checks for running instances in Server Emulator module
	v2.6
	--new Server Emulator and Service by ColdZero
	v2.5
	--added checks to prevent task scheduling in case no service is running
	--added some extra pause commands to make process more transparent
	--fixed some little bugs
	v2.4b
	--fixed little bug in task scheduler
	v2.4
	--added Server Emulator as additional option and switched instant activation to use it
	v2.3
	--added modded Service by ColdZero
	v2.2c
	--bugfixing
	v2.2b
	--implement new Service by CODYQX4 (see Features)
	v2.2
	--instant activation mode added (server install, activation process with choice what to activate, server uninstall)
	v2.1c
	--added new versions of KMS Server Service and KMS Client Emulator (released 03.03.2013 by CODYQX4)
	--fixed broken Task Schedule
	v2.1b
	--changed service detection, due to failure on localised Windows versions
	v2.1
	--added option to install service in different start modes
	--added option to task schedule reactivation to start/stop service if installed in manual mode
	v2.0
	--code optimization
	--new menu structure with color codes
	--changed menu input to on-key-press choice
	--added activation check with option to save as text file
	--added choice to Office automatic activation to prevent activating Retail/MAK installs if both are installed
	--added Tools menu to open some Control Panel Applets easily
	--added option to check if service is running
	--added option to enable/delete firewall rules
	--added IP choice for Office reactivation task
	--added log clearance to uninstall and as option
	--added option to halt service
	v1.6
	--fixed bug in Office Activation
	v1.5
	--some code tuning
	--little glitches fixed
	--new colors :)
	v1.4
	--added Office PP VL activation
	--added task for daily reactivation of Office
	v1.3
	--added setup for multiple instances (must have different name and port)
	--added offer for some known ePIDs to enter easily
	--added system reconition for Win 7 / Server 2008R2 family
	--added system recognition for Win 8 / Server 2012 family
	--added key GVLK offer for recognized systems
	--some code optimization
	v1.2
	--added IP lookup for host machine
	--added new choice options for server restart task schedule
	--added new choice options for host reactivation task schedule
	v1.1
	--slight bugfixing (forgot highest privileges for task in scheduler)
	--added activation for host
	--schedule task for daily reactivation of host
	v1.0
	--initial release