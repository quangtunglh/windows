SECO Injector - SppExtComObj Hook with an integrated KMS Server
=================================================================
Version : 2.4.2
=================================================================
Registry Settings :

HKEY_LOCAL_MACHINE\SOFTWARE\SECOInjector

"Enabled" ( REG_DWORD ) : 1 = On, 0 = Off

"KMS_Emulation" (REG_DWORD ) : 1 = On, 0 = Off ( If emulation is not used it will redirect the kms ip to localhost )

"KMS_IP" (REG_SZ) : eg. 8.8.8.8, 4.5.6.7, 123.123.123.123

"KMS_ActivationInterval" (REG_DWORD) : 120 (Default)

"KMS_RenewaInterval" (REG_DWORD) : 10080 (Default)
=================================================================
Notes :
- Please run Settings.reg before you start the injector or the service
=================================================================
~CyNecx, http://cynecx.net/files, MyDigitalLife.info
=================================================================
December 25th, 2013
=================================================================
Happy Christmas and a happy new YEAR to everyone <3
