___________.__              ____ ___      .__                                  .__     
\__    ___/|  |__   ____   |    |   \____ |__|__  __ ___________  ___________  |  |    
  |    |   |  |  \_/ __ \  |    |   /    \|  \  \/ // __ \_  __ \/  ___/\__  \ |  |    
  |    |   |   Y  \  ___/  |    |  /   |  \  |\   /\  ___/|  | \/\___ \  / __ \|  |__  
  |____|   |___|  /\___  > |______/|___|  /__| \_/  \___  >__|  /____  >(____  /____/  
    __________._\/_____\/_    _________ \/_             \/    __     \/      \/        
    \______   \   \______ \   \_   ___ \|  |__   ____   ____ |  | __ ___________ 
     |     ___/   ||    |  \  /    \  \/|  |  \_/ __ \_/ ___\|  |/ // __ \_  __ \
     |    |   |   ||    `   \ \     \___|   Y  \  ___/\  \___|    <\  ___/|  | \/
     |____|   |___/_______  /  \______  /___|  /\___  >\___  >__|_ \\___  >__|   
                          \/          \/     \/     \/     \/     \/    \/v1.1.3.590
    =============================================================================  

 I. Program description
 ----------------------                                                        
                                                                               
        The Universal PID Checker allows you to calculate the Product ID of    
        given product key. Key validity will be checked also. The unique       
        feature is reading keys from file and saving log. Performance   
        of PID generation is checked too - time spent on generating will be       
        shown under the result.

        Features:

         - Generating PID from typed key/clipboard
                * for Windows 8/Server 2012
                * for Windows 7/Server 2008 R2
                * for Windows Vista/Server 2008
                * for Windows XP/Server 2003
                * for Office 2010 and 2013
		* for current system
		* for all builds >= 6.0.5365.8
         - Generating PID from file
         - Saving output to log 
	 - Viewing system key
	 - Drag'n'Drop support
	
                                                                               
 II. Usage                                                                     
 ---------                                                                     
   a) from clipboard/manual input:                                             
                                                                               
        1. Enter a 25-digit key (dashes will be added automatically),
	   (if you have it in clipboard, it will be pasted automatically, so
	   select profiles before clicking the edit box).
	2. Windows Flag button pastes your current system key into edit box. 
	3. If you want to check keys for unsupported beta builds, just
	   select "Custom" and choose pkeyconfig file(s).  
        4. You can choose the Log option to log output to file      
        5. Click the "Go!" button to start generating PID.         
        6. "Stop!" button stops planned checking - it can't stop the check that
	   is in progress!               
                                                                               
   b) from file:                                                               
                                                                               
        1. Click "Browse" button and choose file with keys or use Drag'n'Drop. Note that it       
           must be text file containing keys only, one key per one line.
	   Now, file CAN contain spaces.
	2. Select a profile (If you want to check keys for unsupported beta 
	   builds, just select "Custom" and choose pkeyconfig file).                                              
        3. You can choose the Log option to log output to file (recommended).  
        4. Click "Go!" button to start calculating.                            
        5. You will get a message when it is done. Overall time will be shown too.

   c) IdentifyKey:                                                               
                                                                               
        1. Click "Browse" button and choose file with keys or use Drag'n'Drop. Note that it       
           must be text file containing keys only, one key per one line.
	   Now, file CAN contain spaces.
	2. Select a profile(s) (If you want to check keys for unsupported beta 
	   builds, just select "Custom" and choose pkeyconfig file).                                              
        3. You can choose the Log option to log output to file (recommended).  
        4. Click "Go!" button to start calculating.                            
        5. Check your results
 
   d) blacklist: 

	1. Blacklist function lets you check if key is blacklisted by MS.
	2. Put a list of blacklisted keys into txt file, save as blacklist.txt
	   in program folder.
	3. If the key is on your blacklist, program will tell you. 

   e) Drag'n'Drop support

	1. You can easily check multiple keys just by dropping a .txt file on application's
	   window. 
	2. You can also drop .xrm-ms file(s) to use them as pkeyconfigs.
	3. Mixing both methods is supported too!

   Note: You can use pkeyconfigs from build 5365.8 of Vista and newer.

        WARNING! Application author is not responsible for software and hardware
        damages. You are using it on own risk!
                                                                              
 III. System Requirements                                                     
 ------------------------                          
                                                                              
        OS: Windows 2000/XP/Vista/7/Server 2008/Server 2008 R2                     
        RAM: 25MB of free memory                                                 
        CPU: AMD Phenom X2 or Intel Core 2 Duo (~2GHz) for good performance   
        HDD: Application uses about 15MB on disk                             
                                                                             
 IV. Changelog
 -------------

  * v1.1.3.590 (20-12-2012)
                          
        + Added Office 2013 support
	F Fixed Windows Server 2008 bugs

  * v1.1.3.570 (15-08-2012)
                          
        F IdentifyKey for Windows 8 is now fixed

  * v1.1.3.568 (15-08-2012)
                          
        F Batch checking for system profile fixes
	F Batch checking report fixes
	- Removed XP x64 Pidgen files which caused problems on x86 systems 
	+ PidGenX from Windows 8 RTM
	F XP /Server 2003 profile is now "NT 5.x"

  * v1.1.3.560 (07-08-2012)
                          
        F Fixed Edition Type bugs for Volume keys
	F Improved Volume Count function
	+ Added full Windows 8 support (including long CryptoID)
	F Decreased application size
	+ Added Office 15 placeholders

  * v1.1.3.545 (15-07-2012)
                          
        F Fixed bugs in MAK Count checking and improved stability

  * v1.1.3.540 (13-07-2012)
                          
        + Added ability to check MAK Volume Activation Count (beta)

  * v1.1.2.512 (08-07-2012)
                          
        F Fixed graphics glitch on startup (finally)
	F Improved current system pkeyconfig checking
	F Improved automatic dashes putting (now it's working like Microsoft's one)
	F Rebuilt "About..." window

  * v1.1.1.315 (08-03-2012)
                          
        + Extended Drag'n'Drop support
	+ Added current system pkeyconfig checking (6.x) (beta)
	F Improved Description finding function to support Windows 8 Consumer Preview
	F Some disabling function fixes

  * v1.1.0.200 (05-11-2011) [New Milestone]
                          
        + Ability to check one key for multiple profiles at time
	+ Windows Vista SP0, SP1, SP2 and Windows 7 SP0, SP1 configs
	+ PidgenX.dll from Windows 8 build 7989 - increases speed by 5%
	+ IdentifyKey tab
	+ Window can now be resized both vertically and horizontally
	+ RAR compression of needed files (decreases application size)
	+ Log function is back in standard mode
	+ Try SP0 option (check key for SP0 if SP1/2 failed)
	+ Windows XP support (beta)
	+ Drag'n'Drop support
	F Several minor fixes

  * v1.0.4.1 (09-05-2011)
                          
        - Vista SP2 and 7 SP1's pkeyconfigs

  * v1.0.4.0 (22-04-2011)
                          
        + New Interface
	F Fixed Aero Glass bug on Vista

  * v1.0.3.33 (23-10-2010)
                          
        + Increased speed

  * v1.0.3.32 (23-10-2010)
                          
        + Task Dialog emulation on XP

  * v1.0.3.31 (19-09-2010)
                          
        + New compiler
	- File size decreased
	+ Stop button in batch mode
	F Font changes
	F Few instances of pidgen may be opened simultaneously now
	F Pasting current key is now working under NT5.x too
	F About window redesigned
	+ Blacklist support

  * v1.0.3.3 (04-09-2010)             
                          
        F Appearance fixes on XP (Check attached screenshot)
	F "About" button is now disabled during the generation process

  * v1.0.3.2 (31-08-2010)             
                          
        F Custom config support
	F Redesigned "Profile chooser"
	F Taskbar's progressbar fix

  * v1.0.3.1 (20-08-2010)             
                          
        F Better Windows themes compatibility
	F Improved reading from txt
	F Bugfixes

  * v1.0.3.0 (19-08-2010)             
                          
        F GUI improvements
	+ Pasting current system key option
	F Main window is now resizable
	F Txt file with keys can contain spaces now

  * v1.0.2.1 (22-07-2010)             
                          
        F Aero Glass improvements
	- Log function removed from standard mode

  * v1.0.2.0 (19-07-2010)             
                          
        - Application size decreased
	F Bugfixes

  * v1.0.1.0 (19-07-2010)             
                          
        + PIDs are now generated in separate thread
	F Bugfixes
	+ Automatic dashes addition

  * v1.0.0.1 (18-07-2010)             
                          
        + Added a summary on the end of log

  * v1.0.0.0 (18-07-2010)
       
        @ Initial release 

 V. Links
 --------

http://forums.mydigitallife.info/threads/20816
http://janek2012.eu/





